package com.technology.jep.jepriatoolkit.creator.module;

public enum FORM {
	DETAIL_FORM, LIST_FORM, FORM_CONTAINER
}
