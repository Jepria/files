package com.technology.jep.jepriatoolkit.creator.module;

public enum FieldType {
  RECORD, FORM_LIST, FORM_DETAIL
}
